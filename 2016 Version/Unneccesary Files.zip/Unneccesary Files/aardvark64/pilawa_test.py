#!/bin/env python
#==========================================================================
# (c) 2004  Total Phase, Inc.
#--------------------------------------------------------------------------
# Project : Aardvark Sample Code
# File    : aai2c_file.c
#--------------------------------------------------------------------------
# Configure the device as an I2C master and send data.
#--------------------------------------------------------------------------
# Redistribution and use of this file in source and binary forms, with
# or without modification, are permitted.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
#==========================================================================

#==========================================================================
# IMPORTS
#==========================================================================
import sys
from array import array
import time
#from aardvark_py import *


#==========================================================================
# CONSTANTS
#==========================================================================
BUFFER_SIZE = 2048
I2C_BITRATE =  100
PORT  = 1
ADDR1=0x21
ADDR2=0x22
ADDR3=0x23
ADDR4=0x24
PACKET_LENGTH=4

#==========================================================================
# FUNCTIONS
#==========================================================================
def fakeread(addr):
    return_list=[]
    #return_array=array.array("B",[)
    return_list.append(time.strftime('%H%M%S'))
    return_list.append(132)
    return_list.append(32)
    return_list.append(32)
    return_list.append(66)
    return_list.append(89)
    return_list.append(74)
    return_list.append("\n")
    
    data_str= [str(x) for x in return_list]
    datstr='\t'.join(data_str)
    return datstr

def getData(handle, addr):
    t=time.strftime('%H%M%S')
    #send command to slave to begin sending of data
    #aa_i2c_write(handle, addr, AA_I2C_NO_FLAGS, '0x55')
    #(count, data_in) = aa_i2c_read(handle, addr, AA_I2C_NO_FLAGS,PACKET_LENGTH)
    #slave is sending 10-bit values: duty, vin_high, vin_low, vout_high, vout_low, iout_high_iout_low
    dat_array = array.array("I") #create an array of unsigned integer (2 bytes minimum size)
    duty=data_in[0]
    dat_array[0]=duty
    vin=data_in[1]*256+data_in[2]
    dat_array[1]=vin
    vout=data_in[3]*256+data_in[4]
    dat_array[2]=vout
    iout=data_in[5]*256+data_in[6]
    dat_array[3]=iout
    dat_array[4]=t
    data= [str(x) for x in dat_array.tolist()]
    data_str= ','.join(data)
    return data_str

        
#==========================================================================
# MAIN PROGRAM
#==========================================================================
if (len(sys.argv) < 2):
    print "usage: aai2c_file  filename"
    print "  'filename' is the filename where to send processed data"

    sys.exit()

filename = sys.argv[1]
f=open(filename,"w")

header_string=("%time", "duty", "vin", "vout", "iout\n")
f.write('\t'.join(header_string))

#pseudo-code:
#go through each device in a list, read its duty cycle, vin, vout, il

addrList = [ADDR1,ADDR2,ADDR3,ADDR4]
for addr in addrList: 
    #data=getData(handle, addr)
    data=fakeread(addr)
    print(data)
    f.write(data)

f.close()

# Close the device
#aa_close(handle)
