import serial
import time
import sys
import select
import string


class prologix_6060b:
    def __init__(self, prologix=None, addr=None, mode=None, rang=2, debug=False):
        self.prologix  = prologix
        self.addr     = addr
        self.mode     = mode
        self.rang    = rang
        self.debug    = debug
        self.value = 0
        self.initialize()

    def initialize(self):

     	if self.debug: print "Initializing %d for %s" % (self.addr, self.mode)
        self.prologix.set_address(self.addr) # address the proper instrument
        if self.debug: print "Issuing *cls"
        self.prologix.write("*cls")
        self.setMode(self.mode, self.rang) #set mode and range
        if self.debug: print "Issuing trig:imm"
        self.prologix.write("trig:imm") 

    def setSlew(self, value=None):
        self.prologix.set_address(self.addr) # address the proper instrument
        if self.debug: print "Address %d issued %s:SLEW %s" % (self.addr, self.mode, self.value)
        self.prologix.write("%s:SLEW %s" % (self.mode, self.value) )
        
    def setMode(self, mode=None, rang=None):
        #Mode can be CURR, VOLT, RES
        self.mode=mode
        self.prologix.set_address(self.addr) # address the proper instrument
        if self.debug: print "Address %d issued MODE:%s" % (self.addr, self.mode)
        self.prologix.write("MODE:%s" % self.mode)

                        

    def setValue(self, value=None):
        self.value=value
        self.prologix.set_address(self.addr) # address the proper instrument
#	self.prologix.write("%s %s") % (self.mode, value)
        if self.debug: print "Address %d issued %s %s" % (self.addr, self.mode, self.value)
        self.prologix.write("%s %s" % (self.mode, self.value) )
    def readCurrent(self):
        # Read back the data, originally tried fetch here, but read works better as it also initiates the meter
        if self.debug: print "Fetching data from %d:" % self.addr
        self.prologix.set_address(self.addr) # select device
        self.prologix.write("MEAS:CURR?") # fetch value
        data = self.prologix.readline() # read until LF (ascii 10)
        if self.debug: print "Recv:", data
        return data

    def readVoltage(self):
        # Read back the data, originally tried fetch here, but read works better as it also initiates the meter
        if self.debug: print "Fetching data from %d:" % self.addr
        self.prologix.set_address(self.addr) # select device
        self.prologix.write("MEAS:VOLT?") # fetch value
        data = self.prologix.readline() # read until LF (ascii 10)
        if self.debug: print "Recv:", data
        return data

class prologix_6060b2:
    def __init__(self, prologix=None, addr=None, mode=None, rang=2, debug=False):
        self.prologix  = prologix
        self.addr     = addr
        self.mode     = mode
        self.rang    = rang
        self.debug    = debug
        self.value = 0
        self.initialize()

    def initialize(self):

     	if self.debug: print "Initializing %d for %s" % (self.addr, self.mode)
        self.prologix.set_address(self.addr) # address the proper instrument
        self.setMode(self.mode, self.rang) #set mode and range
        if self.debug: print "Issuing trig:imm"
        self.prologix.write("trig:imm") 

    def setSlew(self, value=None):
        self.prologix.set_address(self.addr) # address the proper instrument
        if self.debug: print "Address %d issued %s:SLEW %s" % (self.addr, self.mode, self.value)
        self.prologix.write("%s:SLEW %s" % (self.mode, self.value) )
        
    def setMode(self, mode=None, rang=None):
        #Mode can be CURR, VOLT, RES
        self.mode=mode
        self.prologix.set_address(self.addr) # address the proper instrument
        if self.debug: print "Address %d issued MODE:%s" % (self.addr, self.mode)
        self.prologix.write("MODE:%s" % self.mode)

                        

    def setValue(self, value=None):
        self.value=value
        self.prologix.set_address(self.addr) # address the proper instrument
#	self.prologix.write("%s %s") % (self.mode, value)
        if self.debug: print "Address %d issued %s %s" % (self.addr, self.mode, self.value)
        self.prologix.write("%s %s" % (self.mode, self.value) )
    def readCurrent(self):
        # Read back the data, originally tried fetch here, but read works better as it also initiates the meter
        if self.debug: print "Fetching data from %d:" % self.addr
        self.prologix.set_address(self.addr) # select device
        self.prologix.write("MEAS:CURR?") # fetch value
        data = self.prologix.readline() # read until LF (ascii 10)
        if self.debug: print "Recv:", data
        return data

    def readVoltage(self):
        # Read back the data, originally tried fetch here, but read works better as it also initiates the meter
        if self.debug: print "Fetching data from %d:" % self.addr
        self.prologix.set_address(self.addr) # select device
        self.prologix.write("MEAS:VOLT?") # fetch value
        data = self.prologix.readline() # read until LF (ascii 10)
        if self.debug: print "Recv:", data
        return data

class prologix_6632a:
    def __init__(self, prologix=None, addr=None, mode=None, rang=2, debug=False):
        self.prologix  = prologix
        self.addr     = addr
        self.debug    = debug
        self.value = 0
        self.initialize()

    def initialize(self):
        self.prologix.set_address(self.addr) # address the proper instrument
        self.prologix.write("CLR")
        self.prologix.write("OUT 0")
    def setVoltage(self, value=None):
        self.value=value
        self.prologix.set_address(self.addr)
        self.prologix.write("VSET %s" % self.value )
    def setCurrent(self, value=None):
        self.value=value
        self.prologix.set_address(self.addr)
        self.prologix.write("ISET %s" % self.value )
    def readVoltage(self):
        self.prologix.set_address(self.addr)
        self.prologix.write("VOUT?")
        data = self.prologix.readline()
        return data

    def readCurrent(self, value=None):
        self.prologix.set_address(self.addr)
        self.prologix.write("IOUT?")
        data = self.prologix.readline()
        return data

    def activate(self):
        self.prologix.set_address(self.addr)
        self.prologix.write("OUT 1")
    def deactivate(self):
        self.prologix.set_address(self.addr)
        self.prologix.write("OUT 0")
    def default_setting(self):
        self.prologix.set_address(self.addr)
        self.prologix.write("CLR")

class prologix_6632a2:
    def __init__(self, prologix=None, addr=None, mode=None, rang=2, debug=False):
        self.prologix  = prologix
        self.addr     = addr
        self.debug    = debug
        self.value = 0
        self.initialize()

    def initialize(self):
        x = 0
    def setVoltage(self, value=None):
        self.value=value
        self.prologix.set_address(self.addr)
        self.prologix.write("VSET %s" % self.value )
    def setCurrent(self, value=None):
        self.value=value
        self.prologix.set_address(self.addr)
        self.prologix.write("ISET %s" % self.value )
    def readVoltage(self):
        self.prologix.set_address(self.addr)
        self.prologix.write("VOUT?")
        data = self.prologix.readline()
        return data

    def readCurrent(self, value=None):
        self.prologix.set_address(self.addr)
        self.prologix.write("IOUT?")
        data = self.prologix.readline()
        return data

    def activate(self):
        self.prologix.set_address(self.addr)
        self.prologix.write("OUT 1")
    def deactivate(self):
        self.prologix.set_address(self.addr)
        self.prologix.write("OUT 0")
    def default_setting(self):
        self.prologix.set_address(self.addr)
        self.prologix.write("CLR")
	
class prologix_serial:
    def __init__(self, port, baud=115200, debug=False, lineterm='\n', timeout=60):
        self.port     = port
        self.baudrate = baud
        self.timeout  = timeout
        self.debug    = debug
        self.lineterm = lineterm
        self.serial   = None
        self.initialize()

    def initialize(self):
        if self.serial:
            if self.serial.isOpen(): self.terminate()

        self.serial          = serial.Serial()
        self.serial.port     = self.port
        self.serial.baudrate = self.baudrate
        self.serial.timeout  = self.timeout
        
        try:
            self.serial.open()
        except serial.SerialException, e:
            print "Error opening the serial port!"
            print e
            raise
        else:
            if self.debug: print "Serial port", self.port, "opened:"
            if self.debug: print self.serial

        # Try to read back the prologix controller version to
        #  verify that serial communication works
        if self.debug: print "Fetching controller version..."
        self.write("")
        self.write("++ver")
        version = self.readline()
        if self.debug: print "Ver :", version
        if version == '':
            print "Could not read back controller version!"
            self.terminate()
        self.write("++auto 0") #if 1, issue instrument to talk. This will cause errors if a command such as *CLS is sent, which doesn't require an answer. Can manually read instrument with ++read eoi instead if want to.
        self.write("++eoi 1") #if 1, enables assertion of the EOI signal with the last character sent. Some instruments require this
        self.write("++eos 3")#EOS termination character 0-CR+LF, 1-CR, 2-LF, 3 - None        

    def terminate(self):
        self.serial.close()
        if self.debug: print "Closed port:"
        if self.debug: print self.serial

    def write(self, data):
        self.serial.write(data+self.lineterm)
        if self.debug: print "Sent:", data

    def read(self, length=1):
        data = self.serial.read(size=length)
        if self.debug: print "Recv:", data

    def readline(self):
        self.write("++read 10")
        data = self.serial.readline().strip()
        if self.debug: print "Recv:", data
        return data

    def set_address(self, addr):
        self.write("++addr %d" % addr)

    def trigger_devices(self,devlist):
        self.write("++trg " + " ".join([str(x) for x in devlist]) )



        
class prologix_2400:
    def __init__(self, prologix=None, addr=None, debug=False):
        self.prologix  = prologix
        self.addr     = addr
        self.debug    = debug
        self.initialize()

    def initialize(self):

        self.prologix.set_address(self.addr) # address the proper instrument
	self.prologix.write(":FORM:ELEM VOLT, CURR\n") #setup to read back voltage, current        


    def readData(self):
        # Read back the data, originally tried fetch here, but read works better as it also initiates the meter
        if self.debug: print "Fetching data from %d:" % self.addr
        self.prologix.set_address(self.addr) # select device
        self.prologix.write("READ?") # fetch value
        data = self.prologix.readline() # read until LF (ascii 10)
        if self.debug: print "Recv:", data
        return data

        
class prologix_34401a:
    def __init__(self, prologix=None, addr=None, mode=None, maxrange=None, nplc=None, debug=False):
        self.prologix  = prologix
        self.addr     = addr
        self.mode     = mode
        self.maxrange = maxrange or "DEF"
        self.nplc     = nplc
        self.debug    = debug
        self.initialize()

    def initialize(self):
        # Configure DC measurement (Agilent 34401a)
        # port: serial.Serial()
        # meas: string ("VOLT"|"CURR")
        if self.debug: print "Initializing %d for %s" % (self.addr, self.mode)
        self.prologix.set_address(self.addr) # address the proper instrument
        self.prologix.write("*RST") # reset the meter to its power-on state
        self.prologix.write("*CLS") # clear the status registers
        self.prologix.write("CONF:%s:DC %s,DEF" % (self.mode,self.maxrange))
        if self.nplc: self.prologix.write("%s:DC:NPLC %s" % (self.mode, self.nplc))
        self.prologix.write("zero:auto on") # off,once,on
        self.prologix.write("trig:del 0")
        self.prologix.write("TRIG:SOUR BUS") # bus triggering
        self.prologix.write("TRIG:COUN 1") # one trigger per init cycle

    def waitForTrigger(self):
        self.prologix.set_address(self.addr)
        self.prologix.write("INIT")

    def readData(self):
        # Read back the data
        if self.debug: print "Fetching data from %d:" % self.addr
        self.prologix.set_address(self.addr) # select device
        self.prologix.write("FETC?") # fetch value
        data = self.prologix.readline() # read until LF (ascii 10)
        if self.debug: print "Recv:", data
        return data

class microcontroller_serial_ro:
    def __init__(self, port, baud=9600, debug=True, timeout=60):
        self.port     = port
        self.baudrate = baud
        self.timeout  = timeout
        self.debug    = debug
        self.serial   = None
        self.initialize()

    def initialize(self):
        if self.serial:
            if self.serial.isOpen(): self.terminate()

        self.serial          = serial.Serial()
        self.serial.port     = self.port
        self.serial.baudrate = self.baudrate
        self.serial.timeout  = self.timeout
        
        try:
            self.serial.open()
        except SerialException, e:
            print "Error opening the serial port!"
            print e
            raise 
        else:
            if self.debug: print "Serial port", self.port, "opened:"
            if self.debug: print self.serial

    def terminate(self):
        self.serial.close()
        if self.debug: print "Closed port:"
        if self.debug: print self.serial

    def read(self, length=1):
        data = self.serial.read(size=length)
        if self.debug: print "Recv:", data
        return data

    def readline(self):
        data = self.serial.readline().strip()
        if self.debug: print "Recv:", data
        return data

