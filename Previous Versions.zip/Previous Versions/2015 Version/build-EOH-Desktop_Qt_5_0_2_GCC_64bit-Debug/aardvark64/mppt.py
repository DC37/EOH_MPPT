#!/bin/env python
#==========================================================================
# (c) 2004  Total Phase, Inc.
#--------------------------------------------------------------------------
# Project : Aardvark Sample Code
# File    : aai2c_file.c
#--------------------------------------------------------------------------
# Configure the device as an I2C master and send data.
#--------------------------------------------------------------------------
# Redistribution and use of this file in source and binary forms, with
# or without modification, are permitted.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
#==========================================================================

#==========================================================================
# IMPORTS
#==========================================================================
import sys
import time
from aardvark32.aardvark_py import *
from array import array

#==========================================================================
# CONSTANTS
#==========================================================================
BUFFER_SIZE = 2048
I2C_BITRATE =  50
PORT  = 0
ADDR1=21
ADDR2=22
ADDR3=23
ADDR4=24
PACKET_LENGTH=6
MAX_RESENDS=3 #number of times to resend an i2c message if the count read is not correct

# on Saleae logic, set for 7-bit address display only.
#==========================================================================
# FUNCTIONS
#==========================================================================
def getData(handle, addr):
    data_str=0
    #send command to slave to begin sending of data
    #must turn send_data into a binary array. 0x55 is the command we send to the slave
    count = aa_i2c_write(handle, addr, AA_I2C_NO_FLAGS, array('B',[0x55])) 
    (count, data_in) = aa_i2c_read(handle, addr, AA_I2C_NO_FLAGS,PACKET_LENGTH)
    if (count > 0): #check to see that actually got a response on the address
    #slave is sending 10-bit values: duty, vin_high, vin_low, vout_high, vout_low, iout_high_iout_low
	return_list=[]
	return_list.append(addr)
	return_list.append(time.strftime('%H%M%S'))
	return_list.append(data_in[0]) #duty cycle
	return_list.append(data_in[1]*256+data_in[2]) #vin
	return_list.append(data_in[3]*256+data_in[4]) #vout
	return_list.append(data_in[5]*256+data_in[6]) #iout
	return_list.append("\n")
	data = [str(x) for x in return_list]
	data_str= '\t'.join(data)
        
    return data_str

def readVoltage(handle, addr, numreads): #read back voltage. Send command and number of bytes to read (max 256), and send the whole message twice.
#check to see that the message was indeed completed, or time out. Return voltage if complete, else return -1.
    resends=0
    command_byte=2 #2 is the command for voltage read-back
    transmit_byte_1=numreads>>8 #higher order bits
    transmit_byte_2=numreads & 0xFF
    send_array=array('B',[command_byte, transmit_byte_1,transmit_byte_2,command_byte, transmit_byte_1, transmit_byte_2])
    
    if debug: print "send_array: %s" % send_array
    count = aa_i2c_write(handle, addr, AA_I2C_NO_FLAGS, send_array)
    while ((count != len(send_array)) and resends<MAX_RESENDS):
	time.sleep(1)
	count = aa_i2c_write(handle, addr, AA_I2C_NO_FLAGS, send_array)
	resends=resends+1
	if debug: print "resending, not all bytes sent"
    if debug: print "send count: %d" % count
    (count, data_in) = aa_i2c_read(handle, addr, AA_I2C_NO_FLAGS,PACKET_LENGTH)
    if debug: print "data_in: %s" % data_in
    resends=0
    return 44
#    while (((data_in[0] != data_in[3]) and (data_in[1] != data_in[4]) and (data_in[2] != data_in[5])) and resends < MAX_RESENDS):

#    if len(data_in) != PACKET_LENGTH
    

#==========================================================================
# MAIN PROGRAM
#==========================================================================
if (len(sys.argv) < 2):
    print "usage: aai2c_file  filename"
    print "  'filename' is the filename where to send processed data"

    sys.exit()

filename = sys.argv[1]

handle = aa_open(PORT)
if (handle <= 0):
    print "Unable to open Aardvark device on port %d" % PORT
    print "Error code = %d" % handle
    sys.exit()
    
# Ensure that the I2C subsystem is enabled
aa_configure(handle,  AA_CONFIG_SPI_I2C)
    
# Enable the I2C bus pullup resistors (2.2k resistors).
# This command is only effective on v2.0 hardware or greater.
# The pullup resistors on the v1.02 hardware are enabled by default.
aa_i2c_pullup(handle, AA_I2C_PULLUP_BOTH)

# Enable the Aardvark adapter's power supply.
# This command is only effective on v2.0 hardware or greater.
# The power pins on the v1.02 hardware are not enabled by default.
aa_target_power(handle, AA_TARGET_POWER_BOTH)

# Set the bitrate
bitrate = aa_i2c_bitrate(handle, I2C_BITRATE)
print "Bitrate set to %d kHz" % bitrate


f=open(filename,"w")
header_string=("%addr", "time", "duty", "vin", "vout", "iout\n")
f.write('\t'.join(header_string))

#pseudo-code:
#go through each device in a list, read its duty cycle, vin, vout, il

addrList = [ADDR1,ADDR2,ADDR3,ADDR4]
data=0
while True:
    time.sleep(3)
    #count = aa_i2c_write(handle, 20, AA_I2C_NO_FLAGS, array('B',[0x55])) 
    for addr in addrList:
	voltage=-1
	while voltage==-1: #readVoltage will return -1 if it does no get the right connection
	    voltage=readVoltage(handle, addr, 1)
    
    if (data != 0):
        f.write(data)

f.close()

   
# Close the device
aa_close(handle)
