#!/bin/sh

signal=TERM

# get PID's of processes to kill, then kill them with specified signal
pgrep '^python$' | while read pid
do
   kill -$signal $pid
done
