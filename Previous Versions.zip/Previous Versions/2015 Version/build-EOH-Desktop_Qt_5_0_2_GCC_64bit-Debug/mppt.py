# updatepower.py
# Author: Andrew Morrison
# Based on code from Shibin Qin and Chris Barth

import sys
import time
import datetime
#from aardvark32.aardvark_py import *
from aardvark64.aardvark_py import *
from array import array
from pilawa_instruments import *
import os
import glob
from pylab import *
import csv
import glob
import matplotlib.pyplot as plt
from matplotlib.dates import date2num
import numpy as np
from collections import deque
import matplotlib

font = {'family' : 'normal',
        'weight' : 'bold',
        'size'   : 22}

matplotlib.rc('font', **font)

# Used in combination with a C++ GUI (Executable: Presentation) to update 
# power supply values while a test is in progress

def IVSweep(startvoltage, stopvoltage, file_handle):
    f = file_handle
    print "Doing IV sweep..."
    sweep_voltage=startvoltage
    step_size=(stopvoltage-startvoltage)/30.0 #will be negative if we stop lower than we start

    while (sweep_voltage < stopvoltage): #change here is wanting to go different direction
        eload.setValue(sweep_voltage)
        #time.sleep(0.1)

        eload_voltage= float(eload.readVoltage())
        eload_current= float(eload.readCurrent())
        eload_power = eload_voltage * eload_current

        f.write("%s%s%s\n" % (eload_voltage, ",", eload_power))
        sweep_voltage=sweep_voltage+step_size  #step down in voltage to keep mppt electronics up (for bypass purposes)
    
    print ("IV Voltage sweep done")

# Get insolation values from the GUI
direction = 1

# Set up gpib and power supplies
gpib  = prologix_serial(port="/dev/ttyUSB0", baud=115200, debug=False, timeout=5)
eload= prologix_6060b(prologix=gpib, addr=4, mode="VOLT", rang="20",  debug=False)


f=open("iv.dat","w")
IVSweep(0, 15, f)
f.close()
eload_voltage = []
eload_power = []
eload_data = np.loadtxt("iv.dat", delimiter=',',skiprows=0)
for column in eload_data:
    eload_voltage.append(column[0])
    eload_power.append(column[1])

ion()
power = deque()
time = deque()

x1 = [0]
y1 = [0]

plt.figure(num = 1, figsize = (9,9))
plt.plot(eload_voltage, eload_power, "DarkOrange", linewidth = 4)
p1, = plt.plot(x1, y1, 'ob', markersize = 17)
plt.title("PV Curve")
plt.xlabel("Voltage [V]")
plt.ylabel("Power [W]")
plt.xlim([0, 14])
plt.ylim([0, 40])
thismanager = get_current_fig_manager()
thismanager.window.wm_geometry("+300+0")
plt.draw()

plt.figure(num = 2, figsize = (9,9))
line1, = plot(time, power, 'DarkOrange', linewidth=4)
plt.title("Panel Power Output")
plt.xlabel("Time [s]")
plt.ylabel("Power [W]")
plt.xlim([0, 100])
plt.ylim([0, 40])
thismanager = get_current_fig_manager()
thismanager.window.wm_geometry("+1030+0")
plt.draw()

t = 0


# Set up voltage and current limits (voltage limit is set high because we 
# want to achieve the set current)
f = open("flag.dat", 'r+')
try:
    flag = float(f.read())
except:
    flag = 10
f.close()
f = open("flag.dat", "w")
eload.setValue(flag)
f.write("0")
f.close()

while(t < 100):
    f = open("flag.dat", 'r+')
    try:
        flag = float(f.read())
    except:
        flag = 0
        f.write("0")
        f.close()
    if (flag != 0):
        f = open("flag.dat", "w")
        eload.setValue(flag)
        f.write("0")
        f.close()
    oldvoltage = float(eload.readVoltage())
    oldcurrent = float(eload.readCurrent())
    oldpower = oldvoltage * oldcurrent
    eload.setValue(oldvoltage + direction * 0.1)
    newvoltage = float(eload.readVoltage())
    newcurrent = float(eload.readCurrent())
    newpower = newvoltage * newcurrent
    if (newpower < oldpower):
        direction = direction * -1
    power.append(newpower)
    time.append(t)
    x1 = newvoltage
    y1 = newpower
    t = t + 1
    line1.set_ydata(power)
    line1.set_xdata(time)
    p1.set_ydata(y1)
    p1.set_xdata(x1)
    figure(1)
    plt.draw()
    figure(2)
    plt.draw()

while(1):
    f = open("flag.dat", 'r+')
    try:
        flag = float(f.read())
    except:
        flag = 0
        f.write("0")
        f.close()
    if (flag != 0):
        f = open("flag.dat", "w")
        if (0 < flag <= 12):
            eload.setValue(flag)
        f.write("0")
        f.close()
    oldvoltage = float(eload.readVoltage())
    oldcurrent = float(eload.readCurrent())
    oldpower = oldvoltage * oldcurrent
    eload.setValue(oldvoltage + direction * 0.1)
    newvoltage = float(eload.readVoltage())
    newcurrent = float(eload.readCurrent())
    newpower = newvoltage * newcurrent
    if (newpower < oldpower):
        direction = direction * -1
    power.append(newpower)
    time.append(t)
    x1 = newvoltage
    y1 = newpower
    power.popleft()
    time.popleft()
    t = t + 1
    line1.set_ydata(power)
    line1.set_xdata(time)
    p1.set_ydata(y1)
    p1.set_xdata(x1)
    figure(1)
    plt.draw()
    figure(2)
    plt.xlim([t - 100, t])
    plt.draw()

# Terminate gpib connection so that we can access again later
gpib.terminate()
